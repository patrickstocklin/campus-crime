
**************************************************************************
              ReadMe file for Campus Safety and Security 2010
                                          
              Prepared by IT Innovative Solutions - Dec 13,2010
**************************************************************************


Crime2010EXCEL.zip contains the following files:

        Noncampusarrest070809.xls -- noncampus arrest data for year 2007, year 2008 and 2009
        Noncampuscrime070809.xls -- noncampus criminal offenses data for year 2007, year 2008 and 2009
        Noncampusdiscipline070809.xls -- noncampus disciplinary actions data for year 2007, year 2008 and 2009
        Noncampushate070809.xls -- noncampus hate crimes data for year 2007, year 2008 and 2009
        Oncampusarrest070809.xls -- on-campus arrest data for year 2007, year 2008 and 2009
        Oncampuscrime070809.xls -- on-campus criminal offenses data for year 2007, year 2008 and 2009
        Oncampusdiscipline070809.xls -- on-campus disciplinary actions data for year 2007, year 2008 and 2009
        Oncampushate070809.xls -- on-campus hate crimes data for year 2007, year 2008 and 2009
        Publicpropertyarrest070809.xls -- public property arrest data for year 2007, year 2008 and 2009
        Publicpropertycrime070809.xls -- public property criminal offenses data for year 2007, year 2008 and 2009
        Publicpropertydiscipline070809.xls -- public property disciplinary actions data for year 2007, year 2008 and 2009
        Publicpropertyhate070809.xls -- public propert hate crimes data for year 2007, year 2008 and 2009
        Reportedarrest070809.xls -- reported arrest data for year 2007, year 2008 and 2009
        Reportedcrime070809.xls -- reported criminal offenses data for year 2007, year 2008 and 2009
        Reporteddiscipline070809.xls -- reported disciplinary actions data for year 2007, year 2008 and 2009
        Reportedhate070809.xls -- reported hate crimes data for year 2007, year 2008 and 2009
        Residencehallarrest070809.xls -- residence hall arrest data for year 2007, year 2008 and 2009
        Residencehallcrime070809.xls -- residence hall criminal offenses data for year 2007, year 2008 and 2009
        Residencehalldiscipline070809.xls -- residence hall disciplinary actions data for year 2007, year 2008 and 2009
        Residencehallfire09.xls -- residence hall fire data for year 2009
        Residencehallhate070809.xls -- residence hall hate crimes data for year 2007, year 2008 and 2009
      

Data Dictionaries for Each Excel File
        Noncampusarrest070809_Doc.doc
        Noncampuscrime070809_Doc.doc
        Noncampusdiscipline070809_Doc.doc
        Noncampushate070809_Doc.doc
        Oncampusarrest070809_Doc.doc
        Oncampuscrime070809_Doc.doc
        Oncampusdiscipline070809_Doc.doc
        Oncampushate070809_Doc.doc
        Publicpropertyarrest070809_Doc.doc
        Publicpropertycrime070809_Doc.doc
        Publicpropertydiscipline070809_Doc.doc
        Publicpropertyhate070809_Doc.doc
        Reportedarrest070809_Doc.doc
        Reportedcrime070809_Doc.doc
        Reporteddiscipline070809_Doc.doc
        Reportedhate070809_Doc.doc
        Residencehallarrest070809_Doc.doc
        Residencehallcrime070809_Doc.doc
        Residencehalldiscipline0708_Doc.doc
        Residencehallfire09_Doc.doc
        Residencehallhate070809_Doc.doc
   
   __________________________________________________________________________ 

