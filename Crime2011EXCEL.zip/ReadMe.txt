
**************************************************************************
              ReadMe file for Campus Safety and Security 2011
                                          
              Prepared by IT Innovative Solutions - DEC 12, 2011 
**************************************************************************


Crime2011EXCEL.zip contains the following files:

        Noncampusarrest080910.xls -- noncampus arrest data for year 2008, year 2009 and 2010
        Noncampuscrime080910.xls -- noncampus criminal offenses data for year 2008, year 2009 and 2010
        Noncampusdiscipline080910.xls -- noncampus disciplinary actions data for year 2008, year 2009 and 2010
        Noncampushate080910.xls -- noncampus hate crimes data for year 2008, year 2009 and 2010
        Oncampusarrest080910.xls -- on-campus arrest data for year 2008, year 2009 and 2010
        Oncampuscrime080910.xls -- on-campus criminal offenses data for year 2008, year 2009 and 2010
        Oncampusdiscipline080910.xls -- on-campus disciplinary actions data for year 2008, year 2009 and 2010
        Oncampushate080910.xls -- on-campus hate crimes data for year 2008, year 2009 and 2010
        Publicpropertyarrest080910.xls -- public property arrest data for year 2008, year 2009 and 2010
        Publicpropertycrime080910.xls -- public property criminal offenses data for year 2008, year 2009 and 2010
        Publicpropertydiscipline080910.xls -- public property disciplinary actions data for year 2008, year 2009 and 2010
        Publicpropertyhate080910.xls -- public propert hate crimes data for year 2008, year 2009 and 2010
        Reportedarrest080910.xls -- reported arrest data for year 2008, year 2009 and 2010
        Reportedcrime080910.xls -- reported criminal offenses data for year 2008, year 2009 and 2010
        Reporteddiscipline080910.xls -- reported disciplinary actions data for year 2008, year 2009 and 2010
        Reportedhate080910.xls -- reported hate crimes data for year 2008, year 2009 and 2010
        Residencehallarrest080910.xls -- residence hall arrest data for year 2008, year 2009 and 2010
        Residencehallcrime080910.xls -- residence hall criminal offenses data for year 2008, year 2009 and 2010
        Residencehalldiscipline080910.xls -- residence hall disciplinary actions data for year 2008, year 2009 and 2010
        Residencehallfire09.xls -- residence hall fire data for year 2009
        Residencehallfire10.xls -- residence hall fire data for year 2010
        Residencehallhate080910.xls -- residence hall hate crimes data for year 2008, year 2009 and 2010
      

Data Dictionaries for Each Excel File
        Noncampusarrest080910_Doc.doc
        Noncampuscrime080910_Doc.doc
        Noncampusdiscipline080910_Doc.doc
        Noncampushate080910_Doc.doc
        Oncampusarrest080910_Doc.doc
        Oncampuscrime080910_Doc.doc
        Oncampusdiscipline080910_Doc.doc
        Oncampushate080910_Doc.doc
        Publicpropertyarrest080910_Doc.doc
        Publicpropertycrime080910_Doc.doc
        Publicpropertydiscipline080910_Doc.doc
        Publicpropertyhate080910_Doc.doc
        Reportedarrest080910_Doc.doc
        Reportedcrime080910_Doc.doc
        Reporteddiscipline080910_Doc.doc
        Reportedhate080910_Doc.doc
        Residencehallarrest080910_Doc.doc
        Residencehallcrime080910_Doc.doc
        Residencehalldiscipline0708_Doc.doc
        Residencehallfire09_Doc.doc
        Residencehallfire10_Doc.doc
        Residencehallhate080910_Doc.doc
   
   __________________________________________________________________________ 

