
**************************************************************************
                  ReadMe file for Campus Crime 2009
                                          
                   Prepared by Westat - Dec 1,2009
**************************************************************************


Crime2009EXCEL.zip contains the following files:

        Noncampusarrest060708.xls -- noncampus arrest data for year 2006, year 2007 and 2008
        Noncampuscrime060708.xls -- noncampus criminal offenses data for year 2006, year 2007 and 2008
        Noncampusdiscipline060708.xls -- noncampus disciplinary actions data for year 2006, year 2007 and 2008
        Noncampushate060708.xls -- noncampus hate crimes data for year 2006, year 2007 and 2008
        Oncampusarrest060708.xls -- on-campus arrest data for year 2006, year 2007 and 2008
        Oncampuscrime060708.xls -- on-campus criminal offenses data for year 2006, year 2007 and 2008
        Oncampusdiscipline060708.xls -- on-campus disciplinary actions data for year 2006, year 2007 and 2008
        Oncampushate060708.xls -- on-campus hate crimes data for year 2006, year 2007 and 2008
        Publicpropertyarrest060708.xls -- public property arrest data for year 2006, year 2007 and 2008
        Publicpropertycrime060708.xls -- public property criminal offenses data for year 2006, year 2007 and 2008
        Publicpropertydiscipline060708.xls -- public property disciplinary actions data for year 2006, year 2007 and 2008
        Publicpropertyhate060708.xls -- public propert hate crimes data for year 2006, year 2007 and 2008
        Reportedarrest060708.xls -- reported arrest data for year 2006, year 2007 and 2008
        Reportedcrime060708.xls -- reported criminal offenses data for year 2006, year 2007 and 2008
        Reporteddiscipline060708.xls -- reported disciplinary actions data for year 2006, year 2007 and 2008
        Reportedhate060708.xls -- reported hate crimes data for year 2006, year 2007 and 2008
        Residencehallarrest060708.xls -- residence hall arrest data for year 2006, year 2007 and 2008
        Residencehallcrime060708.xls -- residence hall criminal offenses data for year 2006, year 2007 and 2008
        Residencehalldiscipline0708.xls -- residence hall disciplinary actions data for year 2007 and 2008
        Residencehallhate060708.xls -- residence hall hate crimes data for year 2006, year 2007 and 2008
      

Data Dictionaries for Each Excel File
        Noncampusarrest060708_Doc.doc
        Noncampuscrime060708_Doc.doc
        Noncampusdiscipline060708_Doc.doc
        Noncampushate060708_Doc.doc
        Oncampusarrest060708_Doc.doc
        Oncampuscrime060708_Doc.doc
        Oncampusdiscipline060708_Doc.doc
        Oncampushate060708_Doc.doc
        Publicpropertyarrest060708_Doc.doc
        Publicpropertycrime060708_Doc.doc
        Publicpropertydiscipline060708_Doc.doc
        Publicpropertyhate060708_Doc.doc
        Reportedarrest060708_Doc.doc
        Reportedcrime060708_Doc.doc
        Reporteddiscipline060708_Doc.doc
        Reportedhate060708_Doc.doc
        Residencehallarrest060708_Doc.doc
        Residencehallcrime060708_Doc.doc
        Residencehalldiscipline0708_Doc.doc
        Residencehallhate060708_Doc.doc
   
   __________________________________________________________________________ 

