
**************************************************************************
                  ReadMe file for Campus Crime 2008
                                          
                   Prepared by Westat - Jan 13,2009
**************************************************************************


Crime2008EXCEL.zip contains the following files:

	Noncampusarrest050607.xls -- noncampus arrest data for year 2005, year 2006 and 2007
	Noncampuscrime050607.xls -- noncampus criminal offenses data for year 2005, year 2006 and 2007
	Noncampusdiscipline050607.xls -- noncampus disciplinary actions data for year 2005, year 2006 and 2007
	Noncampushate050607.xls -- noncampus hate crimes data for year 2005, year 2006 and 2007
	Oncampusarrest050607.xls -- on-campus arrest data for year 2005, year 2006 and 2007
	Oncampuscrime050607.xls -- on-campus criminal offenses data for year 2005, year 2006 and 2007
	Oncampusdiscipline050607.xls -- on-campus disciplinary actions data for year 2005, year 2006 and 2007
	Oncampushate050607.xls -- on-campus hate crimes data for year 2005, year 2006 and 2007
	Publicpropertyarrest050607.xls -- public property arrest data for year 2005, year 2006 and 2007
	Publicpropertycrime050607.xls -- public property criminal offenses data for year 2005, year 2006 and 2007
	Publicpropertydiscipline050607.xls -- public property disciplinary actions data for year 2005, year 2006 and 2007
	Publicpropertyhate050607.xls -- public propert hate crimes data for year 2005, year 2006 and 2007
	Reportedarrest050607.xls -- reported arrest data for year 2005, year 2006 and 2007
	Reportedcrime050607.xls -- reported criminal offenses data for year 2005, year 2006 and 2007
	Reporteddiscipline050607.xls -- reported disciplinary actions data for year 2005, year 2006 and 2007
	Reportedhate050607.xls -- reported hate crimes data for year 2005, year 2006 and 2007
	Residencehallarrest050607.xls -- residence hall arrest data for year 2005, year 2006 and 2007
	Residencehallcrime050607.xls -- residence hall criminal offenses data for year 2005, year 2006 and 2007
	Residencehallhate050607.xls -- residence hall hate crimes data for year 2005, year 2006 and 2007
      

Data Dictionaries for Each Excel File
	Noncampusarrest050607_Doc.doc
	Noncampuscrime050607_Doc.doc
	Noncampusdiscipline050607_Doc.doc
	Noncampushate050607_Doc.doc
	Oncampusarrest050607_Doc.doc
	Oncampuscrime050607_Doc.doc
	Oncampusdiscipline050607_Doc.doc
	Oncampushate050607_Doc.doc
	Publicpropertyarrest050607_Doc.doc
	Publicpropertycrime050607_Doc.doc
	Publicpropertydiscipline050607_Doc.doc
	Publicpropertyhate050607_Doc.doc
	Reportedarrest050607_Doc.doc
	Reportedcrime050607_Doc.doc
	Reporteddiscipline050607_Doc.doc
	Reportedhate050607_Doc.doc
	Residencehallarrest050607_Doc.doc
	Residencehallcrime050607_Doc.doc
	Residencehallhate050607_Doc.doc
   
   __________________________________________________________________________ 

