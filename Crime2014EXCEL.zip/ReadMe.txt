
**************************************************************************
              ReadMe file for Campus Safety and Security 2014
                                          
              Prepared by IT Innovative Solutions - DEC 14, 2014 
**************************************************************************


Crime2014EXCEL.zip contains the following files:

        Noncampusarrest111213.xls -- noncampus arrest data for year 2011, year 2012 and 2013
        Noncampuscrime111213.xls -- noncampus criminal offenses data for year 2011, year 2012 and 2013
        Noncampusdiscipline111213.xls -- noncampus disciplinary actions data for year 2011, year 2012 and 2013
        Noncampushate111213.xlsx -- noncampus hate crimes data for year 2011, year 2012 and 2013
        Oncampusarrest111213.xls -- on-campus arrest data for year 2011, year 2012 and 2013
        Oncampuscrime111213.xls -- on-campus criminal offenses data for year 2011, year 2012 and 2013
        Oncampusdiscipline111213.xls -- on-campus disciplinary actions data for year 2011, year 2012 and 2013
        Oncampushate111213.xlsx -- on-campus hate crimes data for year 2011, year 2012 and 2013
        Publicpropertyarrest111213.xls -- public property arrest data for year 2011, year 2012 and 2013
        Publicpropertycrime111213.xls -- public property criminal offenses data for year 2011, year 2012 and 2013
        Publicpropertydiscipline111213.xls -- public property disciplinary actions data for year 2011, year 2012 and 2013
        Publicpropertyhate111213.xlsx -- public propert hate crimes data for year 2011, year 2012 and 2013
        Reportedarrest111213.xls -- reported by local police arrest data for year 2011, year 2012 and 2013
        Reportedcrime111213.xls -- reported by local police criminal offenses data for year 2011, year 2012 and 2013
        Reporteddiscipline111213.xls -- reported by local police disciplinary actions data for year 2011, year 2012 and 2013
        Reportedhate111213.xlsx -- reported by local police hate crimes data for year 2011, year 2012 and 2013
        Residencehallarrest111213.xls -- residence hall arrest data for year 2011, year 2012 and 2013
        Residencehallcrime111213.xls -- residence hall criminal offenses data for year 2011, year 2012 and 2013
        Residencehalldiscipline111213.xls -- residence hall disciplinary actions data for year 2011, year 2012 and 2013
        Residencehallhate111213.xlsx -- residence hall hate crimes data for year 2011, year 2012 and 2013
	Residencehallfire11.xls -- residence hall fire data for year 2011
        Residencehallfire12.xls -- residence hall fire data for year 2012
	Residencehallfire13.xls -- residence hall fire data for year 2013
        
      

Data Dictionaries for Each Excel File
        Noncampusarrest111213_Doc.doc
        Noncampuscrime111213_Doc.doc
        Noncampusdiscipline111213_Doc.doc
        Noncampushate111213_Doc.doc
        Oncampusarrest111213_Doc.doc
        Oncampuscrime111213_Doc.doc
        Oncampusdiscipline111213_Doc.doc
        Oncampushate111213_Doc.doc
        Publicpropertyarrest111213_Doc.doc
        Publicpropertycrime111213_Doc.doc
        Publicpropertydiscipline111213_Doc.doc
        Publicpropertyhate111213_Doc.doc
        Reportedarrest111213_Doc.doc
        Reportedcrime111213_Doc.doc
        Reporteddiscipline111213_Doc.doc
        Reportedhate111213_Doc.doc
        Residencehallarrest111213_Doc.doc
        Residencehallcrime111213_Doc.doc
        Residencehalldiscipline0708_Doc.doc
	Residencehallhate111213_Doc.doc
        Residencehallfire11_Doc.doc
        Residencehallfire12_Doc.doc
	Residencehallfire13_Doc.doc
        
   
   __________________________________________________________________________ 

