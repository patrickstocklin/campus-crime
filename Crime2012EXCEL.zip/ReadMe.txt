
**************************************************************************
              ReadMe file for Campus Safety and Security 2012
                                          
              Prepared by IT Innovative Solutions - DEC 12, 2012 
**************************************************************************


Crime2012EXCEL.zip contains the following files:

        Noncampusarrest091011.xls -- noncampus arrest data for year 2009, year 2010 and 2011
        Noncampuscrime091011.xls -- noncampus criminal offenses data for year 2009, year 2010 and 2011
        Noncampusdiscipline091011.xls -- noncampus disciplinary actions data for year 2009, year 2010 and 2011
        Noncampushate091011.xls -- noncampus hate crimes data for year 2009, year 2010 and 2011
        Oncampusarrest091011.xls -- on-campus arrest data for year 2009, year 2010 and 2011
        Oncampuscrime091011.xls -- on-campus criminal offenses data for year 2009, year 2010 and 2011
        Oncampusdiscipline091011.xls -- on-campus disciplinary actions data for year 2009, year 2010 and 2011
        Oncampushate091011.xls -- on-campus hate crimes data for year 2009, year 2010 and 2011
        Publicpropertyarrest091011.xls -- public property arrest data for year 2009, year 2010 and 2011
        Publicpropertycrime091011.xls -- public property criminal offenses data for year 2009, year 2010 and 2011
        Publicpropertydiscipline091011.xls -- public property disciplinary actions data for year 2009, year 2010 and 2011
        Publicpropertyhate091011.xls -- public propert hate crimes data for year 2009, year 2010 and 2011
        Reportedarrest091011.xls -- reported arrest data for year 2009, year 2010 and 2011
        Reportedcrime091011.xls -- reported criminal offenses data for year 2009, year 2010 and 2011
        Reporteddiscipline091011.xls -- reported disciplinary actions data for year 2009, year 2010 and 2011
        Reportedhate091011.xls -- reported hate crimes data for year 2009, year 2010 and 2011
        Residencehallarrest091011.xls -- residence hall arrest data for year 2009, year 2010 and 2011
        Residencehallcrime091011.xls -- residence hall criminal offenses data for year 2009, year 2010 and 2011
        Residencehalldiscipline091011.xls -- residence hall disciplinary actions data for year 2009, year 2010 and 2011
        Residencehallhate091011.xls -- residence hall hate crimes data for year 2009, year 2010 and 2011
	Residencehallfire09.xls -- residence hall fire data for year 2009
        Residencehallfire10.xls -- residence hall fire data for year 2010
	Residencehallfire11.xls -- residence hall fire data for year 2011
        
      

Data Dictionaries for Each Excel File
        Noncampusarrest091011_Doc.doc
        Noncampuscrime091011_Doc.doc
        Noncampusdiscipline091011_Doc.doc
        Noncampushate091011_Doc.doc
        Oncampusarrest091011_Doc.doc
        Oncampuscrime091011_Doc.doc
        Oncampusdiscipline091011_Doc.doc
        Oncampushate091011_Doc.doc
        Publicpropertyarrest091011_Doc.doc
        Publicpropertycrime091011_Doc.doc
        Publicpropertydiscipline091011_Doc.doc
        Publicpropertyhate091011_Doc.doc
        Reportedarrest091011_Doc.doc
        Reportedcrime091011_Doc.doc
        Reporteddiscipline091011_Doc.doc
        Reportedhate091011_Doc.doc
        Residencehallarrest091011_Doc.doc
        Residencehallcrime091011_Doc.doc
        Residencehalldiscipline0708_Doc.doc
	Residencehallhate091011_Doc.doc
        Residencehallfire09_Doc.doc
        Residencehallfire10_Doc.doc
	Residencehallfire11_Doc.doc
        
   
   __________________________________________________________________________ 

